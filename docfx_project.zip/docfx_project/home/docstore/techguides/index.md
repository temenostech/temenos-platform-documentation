# Technical Guides Page

[DevOps - Bank Setup with T24 Sandbox](./doclist/DevOpsBank_setup_with_T24SandBox v2.docx)  
[Create a Package from Design Studio](./doclist/CreatingPackage.docx)  
[T24 Graphical Physical and Logical Viewer in Design Studio](./doclist/DesignStudioT24-Workshop_GDV.docx)  
[Design Studio Topologies](./doclist/DS topologies.pdf)  